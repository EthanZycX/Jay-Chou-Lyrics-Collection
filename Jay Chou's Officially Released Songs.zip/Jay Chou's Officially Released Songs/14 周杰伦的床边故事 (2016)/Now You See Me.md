Now You See Me
[00:00.00] 作词 : 方文山
[00:01.00] 作曲 : 周杰伦
[00:02.00] 编曲 : 黄雨勋
[00:03.00] 制作人 : 周杰伦
[00:04.00] 吉他 : 黄雨勋
[00:05.00] 录音师 : 杨瑞代 Gary Yang/黄雨勋
[00:06.00] 录音室 : JVR Studio/梦想之翼
[00:07.00] 混音师 : 黄雨勋
[00:08.00] 混音室 : 梦想之翼
[00:09.00] OP : JVR Music Int’l Ltd.
[00:10.00] SP : Universal Music Publishing Ltd. Taiwan
[00:30.79]我的幻术是超能力
[00:32.29]我天生神力
[00:33.39]你的魔术要靠道具
[00:34.84]还真不给力
[00:35.84]你话术耍耍嘴皮
[00:36.94]声东击西分散注意
[00:38.39]我根本不理
[00:39.14]省点力气你还真有耐性
[00:41.20]啊玩一玩纸牌
[00:42.70]消失了钱币
[00:43.95]手里变出白鸽
[00:45.05]都是小朋友的把戏
[00:46.60]猜你应该使用了障眼的把戏
[00:48.75]不然你看一看你旁边的观众
[00:50.15]他们都跑到哪去
[00:52.45]出神入化雾里看花
[00:55.00]跟我拼命你会输掉所有筹码
[00:57.44]出神入化浪迹天涯
[01:00.14]认真起来我连我自己都害怕
[01:02.04]Now you see me cuz I let it be
[01:04.69]Wanna find the key you gotta follow my beat
[01:06.89]Now you see me cuz I let it be
[01:09.79]我的幻术存在但看不见证据
[01:12.04]Now you see me cuz I let it be
[01:14.84]Wanna find the key you gotta follow my beat
[01:17.09]Now you see me cuz I let it be
[01:19.99]我的幻术让你沉迷看穿你
[01:24.87]
[01:32.87]One two three four
[01:34.17]One two three four
[01:35.57]倒数计时睁开眼
[01:36.82]置身在不同的城市
[01:38.12]One more two more
[01:39.37]One more two more
[01:40.52]你看不见我看不见我看不见我
[01:42.68]看不见我看不见我
[01:44.18]难度就像乌龟翻跟斗
[01:45.93]看不见我
[01:46.73]你就是扶不起的阿斗
[01:48.53]看不见我
[01:49.33]不然你早已跟我握手
[01:51.08]看不见我
[01:51.93]万一看见的人是只小狗
[01:54.38]出神入化雾里看花
[01:56.93]跟我拼命你会输掉所有筹码
[01:59.58]出神入化浪迹天涯
[02:02.13]认真起来我连我自己都害怕
[02:04.18]Now you see me cuz I let it be
[02:06.54]Wanna find the key you gotta follow my beat
[02:08.74]Now you see me cuz I let it be
[02:11.74]我的幻术存在但看不见证据
[02:14.29]Now you see me cuz I let it be
[02:16.74]Wanna find the key you gotta follow my beat
[02:19.39]Now you see me cuz I let it be
[02:22.04]我的幻术让你沉迷看穿你
